```
pod repo add PrivatePods https://github.com/ModulizationDemo/PrivatePods.git

pod update
```
